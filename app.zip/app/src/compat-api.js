// src/compat-api.js

/**
 * Saves a finished game by POSTing to your Express backend.
 * Relies on window.firebaseAuth from your inline compat SDK.
 */
export async function saveGame({ boardState, score, startTime, endTime, metadata = {} }) {
    const auth = window.firebaseAuth;
    if (!auth || !auth.currentUser) {
      throw new Error("User must be signed in to save game");
    }
    // Get a fresh ID token
    const idToken = await auth.currentUser.getIdToken(/* forceRefresh */ true);
  
    // Send to your proxied endpoint
    const resp = await fetch("/save-game", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${idToken}`,
        "Content-Type":  "application/json",
      },
      body: JSON.stringify({ boardState, score, startTime, endTime, metadata }),
    });
  
    if (!resp.ok) {
      const errBody = await resp.json().catch(() => ({}));
      throw new Error(errBody.error || `Save failed: ${resp.status}`);
    }
    return resp.json();
  }
  