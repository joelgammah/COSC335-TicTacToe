// BuildingDeck.jsx
import React from 'react'
import { useTownStore, buildingConfig } from './store.js'

const buildings = Object.keys(buildingConfig)


export default function BuildingDeck() {
  const selectBuilding = useTownStore(s => s.selectBuilding)
  const selectedBuilding = useTownStore(s => s.selectedBuilding)
  const buildingError = useTownStore(s => s.buildingError)

  return (
    <div className="flex space-x-3 mb-4">
      {buildings.map(name => (
        <button
          key={name}
          onClick={() => selectBuilding(name)}
          className={`
            px-3 py-1 rounded border
            ${selectedBuilding===name
              ? 'bg-blue-500 text-white'
              : 'bg-white text-gray-800 hover:bg-blue-50'}
          `}
        >
          {name}
        </button>
      ))}
      {buildingError && (
        <p className="text-red-600 ml-4">{buildingError}</p>
      )}
    </div>
  )
}
