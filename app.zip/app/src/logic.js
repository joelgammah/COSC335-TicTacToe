// src/logic.js
/**
 * @param {Array<string|null>} boardState  16-slot array of resources
 * @param {"X"|"O"|null}      winner
 * @param {string}            idToken  Firebase ID token
 * @returns {Promise<{success: boolean, gameId: string}>}
 */
export async function saveGame(boardState, winner, idToken) {
  const res = await fetch("http://localhost:3000/save-game", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify({
      boardState,
      score: winner === "X" ? 1 : 0, // or however you derive score
      startTime: new Date().toISOString(),  
      endTime:   new Date().toISOString(),
      metadata: {}  
    })
  });
  return res.json();
}

/**
 * @param {string} achievementId  e.g. "perfectTown"
 * @param {string} viaGame        gameId returned from saveGame
 * @param {string} idToken
 */
export async function unlockAchievement(achievementId, viaGame, idToken) {
  const res = await fetch("http://localhost:3000/unlock-achievement", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${idToken}`
    },
    body: JSON.stringify({ achievementId, viaGame })
  });
  return res.json();
}

/** Fetch the catalog of all achievements */
// before: export function fetchDefinitions() { … }

export async function fetchDefinitions() {
  const res = await fetch('/api/achievement-definitions');
  // print status + raw text
  const text = await res.text();
  console.log('[fetchDefinitions] status:', res.status, 'body:', text);
  
  if (!res.ok) {
    throw new Error(`fetchDefinitions failed with status ${res.status}`);
  }
  
  // try parsing
  return JSON.parse(text);
}




/** Fetch the badges this user has unlocked */
export function fetchUserAchievements(idToken) {
  return fetch('/api/user-achievements', {       // ← also go through /api
    headers: { Authorization: `Bearer ${idToken}` }
  }).then(res => res.json())
}
