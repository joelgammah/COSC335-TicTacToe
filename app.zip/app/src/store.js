import { create } from 'zustand'

// ===== Constants & Helpers =====
const allColors = ['yellow', 'red', 'blue', 'brown', 'gray']
const colorToResource = {
  yellow: 'Wheat',
  red:    'Brick',
  blue:   'Glass',
  brown:  'Wood',
  gray:   'Stone'
}
// Reverse lookup: resource name to color key
const resourceToColor = Object.fromEntries(
  Object.entries(colorToResource).map(([color, name]) => [name, color])
)

// Building definitions with base patterns
export const buildingConfig = {
  Cottage: {
    icon: 'cottage_ic.png',
    basePatterns: [
      [
        { color: 'yellow', row: 0, col: 1 },
        { color: 'red',    row: 1, col: 0 },
        { color: 'blue',   row: 1, col: 1 }
      ]
    ]
  },
  Farm: {
    icon: 'farm_ic.png',
    basePatterns: [
      [
        { color: 'yellow', row: 0, col: 0 },
        { color: 'yellow', row: 0, col: 1 },
        { color: 'brown',  row: 1, col: 0 },
        { color: 'brown',  row: 1, col: 1 }
      ]
    ]
  },
  Chapel: {
    icon: 'chapel_ic.png',
    basePatterns: [
      [
        { color: 'blue',  row: 0, col: 2 },
        { color: 'gray',  row: 1, col: 0 },
        { color: 'blue',  row: 1, col: 1 },
        { color: 'gray',  row: 1, col: 2 }
      ]
    ]
  },
  Tavern: {
    icon: 'tavern_ic.png',
    basePatterns: [
      [
        { color: 'red',  row: 0, col: 0 },
        { color: 'red',  row: 0, col: 1 },
        { color: 'blue', row: 0, col: 2 }
      ]
    ]
  },
  Well: {
    icon: 'well_ic.png',
    basePatterns: [
      [
        { color: 'brown', row: 0, col: 0 },
        { color: 'gray',  row: 0, col: 1 }
      ]
    ]
  },
  Theater: {
    icon: 'theater_ic.png',
    basePatterns: [
      [
        { color: 'gray',  row: 0, col: 1 },
        { color: 'brown', row: 1, col: 0 },
        { color: 'blue',  row: 1, col: 1 },
        { color: 'brown', row: 1, col: 2 }
      ]
    ]
  },
  Factory: {
    icon: 'factory_ic.png',
    basePatterns: [
      [
        { color: 'brown', row: 0, col: 0 },
        { color: 'red',   row: 1, col: 0 },
        { color: 'gray',  row: 1, col: 1 },
        { color: 'gray',  row: 1, col: 2 },
        { color: 'red',   row: 1, col: 3 }
      ]
    ]
  },
  Catedral: {
    icon: 'monu_ic.png',
    basePatterns: [
      [
        { color: 'yellow', row: 0, col: 1 },
        { color: 'gray',   row: 1, col: 0 },
        { color: 'blue',   row: 1, col: 1 }
      ]
    ]
  }
}

// Transform helpers
function rotate90(pattern) {
  return pattern.map(({ color, row, col }) => ({ color, row: col, col: -row }))
}
function flipHorizontal(pattern) {
  return pattern.map(({ color, row, col }) => ({ color, row, col: -col }))
}
function normalizePattern(pattern) {
  const minRow = Math.min(...pattern.map(p => p.row))
  const minCol = Math.min(...pattern.map(p => p.col))
  return pattern
    .map(p => ({ color: p.color, row: p.row - minRow, col: p.col - minCol }))
    .sort((a, b) => (a.row === b.row ? a.col - b.col : a.row - b.row))
}
function generateAllTransformations(base) {
  const results = []
  const original = normalizePattern(base)
  results.push(original)
  let current = original
  for (let i = 0; i < 3; i++) {
    current = normalizePattern(rotate90(current))
    results.push(current)
  }
  let flipped = normalizePattern(flipHorizontal(original))
  results.push(flipped)
  current = flipped
  for (let i = 0; i < 3; i++) {
    current = normalizePattern(rotate90(current))
    results.push(current)
  }
  return results
}
function arraysMatchPositions(a, b) {
  if (a.length !== b.length) return false
  return a.every((p, i) => p.color === b[i].color && p.row === b[i].row && p.col === b[i].col)
}
function isConnected(squaresInfo) {
  if (!squaresInfo.length) return false
  const visited = new Set()
  const queue = [squaresInfo[0]]
  visited.add(`${squaresInfo[0].row},${squaresInfo[0].col}`)
  while (queue.length) {
    const cur = queue.pop()
    for (const [dr, dc] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const nr = cur.row + dr, nc = cur.col + dc
      const key = `${nr},${nc}`
      if (!visited.has(key)) {
        const match = squaresInfo.find(s => s.row === nr && s.col === nc)
        if (match) { visited.add(key); queue.push(match) }
      }
    }
  }
  return visited.size === squaresInfo.length
}

// ===== Zustand Store =====
export const useTownStore = create((set, get) => ({
  grid: Array(16).fill(null),
  resourceDeck: allColors.slice(0,3).map((color,i)=>({id:`${color}-${i}`,color,name:colorToResource[color]})),
  selectedResourceId: null,
  selectedGridIndices: [],
  selectedBuilding: null,
  patternIndices: [],
  mode: 'normal',
  buildingError: null,

  resetGrid: () => set({
    grid: Array(16).fill(null),
    selectedResourceId: null,
    selectedGridIndices: [],
    selectedBuilding: null,
    patternIndices: [],
    mode: 'normal',
    buildingError: null
  }),

  selectResourceCard: id => set(state => ({
    selectedResourceId: state.selectedResourceId===id?null:id,
    selectedGridIndices: []
  })),

  refreshCard: id => set(state => ({
    resourceDeck: state.resourceDeck.map(card => {
      if (card.id !== id) return card
      const newColor = allColors[Math.floor(Math.random() * allColors.length)]
      return { id: card.id, color: newColor, name: colorToResource[newColor] }
    }),
    selectedResourceId: null
  })),

  placeResource: index => set(() => {
    const { selectedResourceId, resourceDeck, grid } = get()
    if (!selectedResourceId || grid[index]!=null) return {}
    const card = resourceDeck.find(c=>c.id===selectedResourceId)
    const newGrid=[...grid]; newGrid[index]=card.name
    const newDeck=resourceDeck.map(c=> {
      if(c.id!==selectedResourceId) return c
      const newColor = allColors[Math.floor(Math.random()*allColors.length)]
      return { id:c.id, color: newColor, name: colorToResource[newColor] }
    })
    return { grid:newGrid, resourceDeck:newDeck, selectedResourceId:null }
  }),

  toggleGridSelection: idx => set(state => {
    const { grid, selectedBuilding, selectedGridIndices } = state
    if (!grid[idx]) return {}
    const maxLen = selectedBuilding ? buildingConfig[selectedBuilding].basePatterns[0].length : Infinity
    const already = selectedGridIndices.includes(idx)
    if (!already && selectedGridIndices.length>=maxLen) return {}
    return {
      selectedGridIndices: already
        ? selectedGridIndices.filter(i=>i!==idx)
        : [...selectedGridIndices, idx]
    }
  }),

  selectBuilding: name => {
    set({ selectedBuilding: name, buildingError: null, selectedGridIndices: [] })
    const { selectedGridIndices, grid } = get()
    if (!selectedGridIndices.length) return
    const squaresInfo = selectedGridIndices.map(i=>{
      const row=Math.floor(i/4), col=i%4, resName=grid[i]
      return { color:resourceToColor[resName], row, col }
    })
    if (!isConnected(squaresInfo)) return set({ buildingError:'Squares not adjacent.' })
    const basePatterns = buildingConfig[name].basePatterns
    const normInfo = normalizePattern(squaresInfo)
    const match = basePatterns.some(base =>
      generateAllTransformations(base).some(tf=> arraysMatchPositions(normInfo,tf))
    )
    if(!match) return set({ buildingError:`Invalid ${name} pattern.` })
    set({ mode:'placingBuilding', patternIndices:selectedGridIndices })
  },

  placeBuildingAt: idx => set(state => {
    const { patternIndices, selectedBuilding, grid } = get()
    if (!patternIndices.includes(idx)) return {}
    const newGrid=[...grid]; newGrid[idx]=selectedBuilding
    patternIndices.forEach(i=>{ if(i!==idx) newGrid[i]=null })
    return { grid:newGrid, selectedBuilding:null, patternIndices:[], mode:'normal' }
  })
}))
