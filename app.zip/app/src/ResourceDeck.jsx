// src/ResourceDeck.jsx
import React from 'react'
import { useTownStore } from './store.js'

// Map your resource “color” names to Tailwind background classes:
const colorClasses = {
  yellow: 'bg-yellow-400',
  red:    'bg-red-500',
  blue:   'bg-blue-400',
  brown:  'bg-yellow-800',
  gray:   'bg-gray-400',
}

export default function ResourceDeck() {
  const resourceDeck       = useTownStore((s) => s.resourceDeck)
  const selectedResourceId = useTownStore((s) => s.selectedResourceId)
  const selectResourceCard = useTownStore((s) => s.selectResourceCard)
  const refreshCard        = useTownStore((s) => s.refreshCard)

  return (
    <div className="flex space-x-4 mb-6">
      {resourceDeck.map((card) => {
        const isSelected = card.id === selectedResourceId
        return (
          <div
            key={card.id}
            onClick={() => selectResourceCard(card.id)}
            className={`
              p-4 border rounded-lg shadow-sm
              cursor-pointer transition
              ${isSelected ? 'ring-4 ring-blue-500' : 'hover:ring-2 hover:ring-blue-300'}
              bg-white text-gray-800
            `}
          >
            {/* Header */}
            <div className="font-semibold mb-2 text-center">
              {card.name}
            </div>

            {/* Colored square */}
            <div className="flex justify-center mb-2">
              <div
                className={`w-6 h-6 ${colorClasses[card.color]} rounded-sm`}
              ></div>
            </div>

            {/* Refresh button */}
            {isSelected && (
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  refreshCard(card.id)
                }}
                className="w-full px-2 py-1 text-xs font-medium bg-yellow-300 rounded hover:bg-yellow-400 transition"
              >
                Refresh
              </button>
            )}
          </div>
        )
      })}
    </div>
  )
}
