// src/TinyTowns.jsx
import React, { useEffect, useState } from 'react';

import ResourceDeck from './ResourceDeck.jsx';
import BuildingDeck from './BuildingDeck.jsx';
import { useTownStore } from './store.js';
import {
  saveGame,
  unlockAchievement,
  fetchDefinitions,
  fetchUserAchievements
} from './logic.js';

export default function TinyTowns() {
  // ----- Zustand store getters -----
  const grid               = useTownStore(s => s.grid);
  const placeResource      = useTownStore(s => s.placeResource);
  const selectBuildingName = useTownStore(s => s.selectBuilding);
  const mode               = useTownStore(s => s.mode);
  const patternIndices     = useTownStore(s => s.patternIndices);
  const placeBuildingAt    = useTownStore(s => s.placeBuildingAt);
  const toggleGridSelection= useTownStore(s => s.toggleGridSelection);
  const selectedResourceId = useTownStore(s => s.selectedResourceId);

  // ----- Local state for achievements -----
  const [definitions, setDefinitions] = useState([]);    // all badges
  const [unlocked,    setUnlocked]    = useState([]);    // user’s badges

  // 1) Load all achievement definitions once
  useEffect(() => {
    fetchDefinitions().then(setDefinitions).catch(console.error);
  }, []);

  // 2) Load this user’s unlocked achievements once they sign in
  useEffect(() => {
    const auth = window.firebaseAuth
    if (!auth) return
    const unsubscribe = auth.onAuthStateChanged(user => {
      if (user) {
        user.getIdToken()
          .then(fetchUserAchievements)
          .then(setUnlocked)
          .catch(console.error)
      } else {
        setUnlocked([])
      }
    })
    return unsubscribe
  }, [])
  ;

  // 3) Detect when the grid is completely filled
  useEffect(() => {
    const isFull = grid.every(cell => cell !== null);
    if (!isFull || definitions.length === 0) return;

    const user = window.firebaseAuth.currentUser
    if (!user) return;

    // fetch fresh token and then save + award
    user.getIdToken()
      .then(async (token) => {
        // a) Save the finished game and get back its ID
        const { success, gameId } = await saveGame(
          grid,
          null,             // winner logic if any
          token
        );
        if (!success) return;

        // b) For each badge definition...
        definitions.forEach(def => {
          const already = unlocked.some(u => u.achievementId === def.id);

          // Example criteria: noEmptyTiles
          if (
            def.criteria.type === 'noEmptyTiles' &&
            isFull &&
            !already
          ) {
            unlockAchievement(def.id, gameId, token).catch(console.error);
          }

          // Example criteria: minScore
          if (
            def.criteria.type === 'minScore' &&
            /* replace this with your actual score calc */ 50 >= def.criteria.requiredValue &&
            !already
          ) {
            unlockAchievement(def.id, gameId, token).catch(console.error);
          }
        });
      })
      .catch(console.error);
  }, [grid, definitions, unlocked]);

  // ----- Cell click logic (unchanged) -----
  const handleCellClick = (i) => {
    if (selectedResourceId !== null) {
      placeResource(i);
      return;
    }
    if (mode === 'placingBuilding' && patternIndices.includes(i)) {
      placeBuildingAt(i);
      return;
    }
    toggleGridSelection(i);
  };

  return (
    <div>
      <ResourceDeck />
      <BuildingDeck />

      <div className="grid grid-cols-4 gap-2">
        {grid.map((cell,i) => {
          const isPattern = patternIndices.includes(i);
          return (
            <div
              key={i}
              onClick={() => handleCellClick(i)}
              className={`
                w-20 h-20 border flex items-center justify-center cursor-pointer
                ${isPattern && mode === 'placingBuilding'
                  ? 'ring-4 ring-green-500'
                  : ''}
              `}
            >
              {cell || <span className="text-gray-400">—</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
